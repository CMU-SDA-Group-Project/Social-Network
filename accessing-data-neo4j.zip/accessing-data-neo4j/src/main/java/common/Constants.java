package common;

public class Constants {
    // redis expire time
    public static final int REDIS_EXPIRE_TIME = 60 * 60 * 24;
}
